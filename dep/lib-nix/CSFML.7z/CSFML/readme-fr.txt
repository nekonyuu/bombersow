Pour installer et utiliser SFML avec votre compilateur pr�f�r�, rendez-vous sur la page des tutoriels :

http://www.sfml-dev.org/tutorials/index-fr.php
